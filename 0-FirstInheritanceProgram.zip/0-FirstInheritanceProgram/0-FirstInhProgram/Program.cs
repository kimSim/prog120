﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0_FirstInhProgram
{
    // defining classes right in the program.cs file!
    // this is NOT a good design in general, doing it here just to make
    // displaying code easier

        public class Vehicle
    {
        public int MaxSpeed { get; set; }
        public string Color { get; set; }
        public float BatteryLevel { get; set; }
        public void Charge()
        {
            BatteryLevel = 1;
        }
    }

    public class Car : Vehicle
    {
        public bool IsConvertible { get; set; }
    }

    public class Motocycle : Vehicle
    {
        public int EngineSize { get; set; }
    }

    public class Truck : Vehicle
    {
        public double MaxWeight { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Truck truck1 = new Truck();
            truck1.BatteryLevel = .5F;
            truck1.Color = "blue";
            truck1.MaxSpeed = 60;
            truck1.MaxWeight = 3000;

            Motocycle mc1 = new Motocycle();
            mc1.BatteryLevel = .9F;
            mc1.Color = "red";
            mc1.MaxSpeed = 140;
            mc1.EngineSize = 600;

            Car car1 = new Car();
            car1.BatteryLevel = .3F;
            car1.Color = "white";
            car1.IsConvertible = true;
            car1.MaxSpeed = 90;

            
        }
    }
}
